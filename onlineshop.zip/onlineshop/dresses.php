<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Online Store</title>
    <!--bootstrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<!--fontawesome CDN-->
<script src="https://kit.fontawesome.com/0dc3042549.js" crossorigin="anonymous"></script>

<!--slick slider-->
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>


<!--custom stylesheet-->
<link rel="stylesheet" href="./css/style.css"/>
<link rel="stylesheet" href="footer.css">

  </head>
  <body>
    <!--header-->
<header>
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-12 col-12">
        <div class="btn-group">
          <button class="btn border dropdown-toggle my-md-4 my-2 text-white" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> LKR </button>

<div class="dropdown-menu">
  <a href="#" class="dropdown-item">RS:</a>
  <a href="#" class="dropdown-item">$</a>
  <a href="#" class="dropdown-item">EURO</a>

</div>
</div>
  </div>

<div class="col-md-4 co-12 text-center">
  <h2 class="my-md-3 site-title text-white">MISSGUIDED</h2>
</div>
<div class="col-md-4 col-12 text-right">
  <p class="my-md-4 header-links">
<a href="http://localhost/onlineshop/signin.html" class="px-2">Sign in</a>
<a href="http://localhost/onlineshop/New%20folder/signup.php?userid=&passid=&username=&address=&country=Default&zip=&email=&en=en&submit=Submit" class="px-1">Create an account</a>
  </p>
</div>

    </div>
  </div>

<div class="container-fluid p-0">
  <nav class="navbar navbar-expand-lg navbar-light bg-light">

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="http://localhost/onlineshop/index.php"> HOME<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/onlineshop/aboutus.php">ABOUT US</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/onlineshop/contact.php">CONTACT</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost/onlineshop/newarrivals.php">NEW ARRIVALS</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="http://localhost/onlineshop/dresses.php">DRESSES</a>
      </li>
    </ul>
  </div>
  <div class="navbar-nav">
    <li class="nav-item border rounded-cicle mx-2 search-icon">
    <i class="fas fa-search p-4"></i>
    </li>
    <li class="nav-item border rounded-cicle mx-2 search-icon">
      <i class="fas fa-shopping-cart p-3"></i>
    </li>
  </div>
</nav>
</div>
</header>


<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script src="./js/new.js"></script>


<br>
<hr> <center><h1> DRESSES </h1></center> <hr>
<br>

<img src="assets/a.jpg"   width="1400" height="540"> <br><br><br> <br> <br><br>

<hr> <center> <h1>NEW ARRIVALS</h1> </center> <hr> <br><br><br><br>
<center>
<div class="col-md-8">
<div class="row">

<div class="col-md-3">
<h4>LONG FROCK</h4>
<img src="assets/bb.jpg" alt="huda beauty" id="images"/>
<p class="list-price text-danger"> List Price: <s>Rs:5000.00</s> </p>
<p class="price"> Our price: Rs:4990.OO </p>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#details-1">Details</button>
</div>


<div class="col-md-3">
<h4> WESTERN FROCK</h4>
<img src="assets/hh.jpg" alt="huda beauty" id="images"/>
<p class="list-price text-danger"> List Price: <s>Rs:6500.00</s> </p>
<p class="price"> Our price: Rs:5300.00 </p>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#details-8">Details</button>
</div>

<div class="col-md-3">
<h4>GRAY FROCK</h4>
<img src="assets/vv.jpeg" alt="huda beauty" id="images"/>
<p class="list-price text-danger"> List Price: <s>Rs:7100.00</s> </p>
<p class="price"> Our price: Rs:6000.00</p>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#details-8">Details</button>
</div>

<br><br><br>

<div class="col-md-3">
<h4> WESTERN WEAR</h4>
<img src="assets/yy.jpg" alt="huda beauty" id="images"/>
<p class="list-price text-danger"> List Price: <s>Rs:5200.00</s> </p>
<p class="price"> Our price: Rs:5000.00 </p>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#details-8">Details</button>
</div>

<div class="col-md-3">
<h4>LACE WHITE FROCK</h4>
<img src="assets/ll.jpg" alt="huda beauty" id="images"/>
<p class="list-price text-danger"> List Price: <s>Rs:6100.00</s> </p>
<p class="price"> Our price: Rs:5990.00 </p>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#details-8">Details</button>
</div>

<div class="col-md-3">
<h4> COTTON DRESS RED</h4>
<img src="assets/cc.jpg" alt="huda beauty" id="images"/>
<p class="list-price text-danger"> List Price: <s>Rs:2300.00</s> </p>
<p class="price"> Our price: Rs:1999.00 </p>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#details-8">Details</button>
</div>

<div class="col-md-3">
<h4> INDO WESTERN DRESS</h4>
<img src="assets/d3.jpg" alt="huda beauty" id="images"/>
<p class="list-price text-danger"> List Price: <s>Rs:8400.00</s> </p>
<p class="price"> Our price: Rs:7000.00 </p>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#details-8">Details</button>
</div>

<div class="col-md-3">
<h4> OFF SHOULDER DRESS</h4>
<img src="assets/ww.jpg" alt="huda beauty" id="images"/>
<p class="list-price text-danger"> List Price: <s>Rs:7500.00</s> </p>
<p class="price"> Our price: Rs:7300.00 </p>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#details-8">Details</button>
</div>


</div>
</div>
</center>



















<!--footer-->
<footer class="footer-distributed">

  <div class="footer-left">
      <img src="assets/source.gif">
    <h3>MISS<span>GUIDED</span></h3>

    <p class="footer-links">
      <a href="#">HOME</a>
      |
      <a href="#">ABOUT US</a>
      |
      <a href="#">COLLECTION</a>
      |
      <a href="#">NEW ARRIVALS</a>
      |
      <a href="#">ACCESSORIES</a>
      |
      <a href="#">DRESSES</a>
    </p>

    <p class="footer-company-name">© 2019 MissGuided Pvt. Ltd.</p>
  </div>

  <div class="footer-center">
    <div>
    <i class="fas fa-map-marker-alt"></i>
        <p><span>No: 251/A,
         Jayasingha Mawatha,</span>
        Nugegoda,
        Sri Lanka
      </p>
    </div>

    <div>
      <i class="fa fa-phone"></i>
      <p>0112-567875</p>
      <br>
      <i class="fa fa-mobile"></i>
      <p>072-5555555</p>
    </div>
    <div>
      <i class="fa fa-envelope"></i>
      <p><a href="mailto:support@eduonix.com">MissGuided@gmail.com</a></p>
    </div>
  </div>
  <div class="footer-right">
    <p class="footer-company-about">
      <span>About Us</span>
     Our company is a multinational e-commerce corporation based in San Jose, California that facilitates consumer-to-consumer and business-to-consumer sales through its website. eBay was founded by Pierre Omidyar in the autumn of 1995, and became a notable success story of the dot-com bubble.
     <a href="cf.html"><input type="button" value="READ MORE"></a></center>
    </p>
    <div class="footer-icons">
      <a href="#"><i class="fab fa-facebook"></i></a>
      <a href="#"><i class="fab fa-twitter"></i></a>
      <a href="#"><i class="fab fa-instagram"></i></a>
      <a href="#"><i class="fab fa-linkedin-in"></i></a>
      <a href="#"><i class="fab fa-google-plus-g"></i></a>
    </div>
  </div>
<center>
  <a href="#">  <i class="fab fa-paypal" style="font-size:20px;"></i> </a>
    <a href="#"> <i class="fas fa-credit-card" style="font-size:20px;"></i></a>
      <a href="#"> <i class="fa fa-money" style="font-size:20px;"></i></a>
        <a href="#"> <i class="fab fa-cc-visa" style="font-size:20px;"></i></a>
          <a href="#"> <i class="fab fa-cc-mastercard" style="font-size:20px;"></i></a>
            <a href="#"> <i class="fab fa-google-wallet" style="font-size:20px;"></i></a>
              <a href="#"> <i class="fa fa-pay.pal" style="font-size:20px;"></i></a>

  </center>
</footer>





</body>
</html>
