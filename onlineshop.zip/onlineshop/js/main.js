/*slider*/
$('.slider-one').slick();
