<?php

session_start();
$connect  = mysqli_connect("localhost" , "root" , "" , "test");

 ?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>ADD TO CART</title>
    <script src="New folder\bootstrap-4.4.1-dist\js\bootstrap.min.js">

    </script>
  </head>
  <body>
    <div class="container" style="width:700px;">
      <h3 align="center">SHOPPING CART</h3> <br>
      <?php

      $query = "SELECT * FROM tbl_product ORDER BY id ASC";
      $result = mysqli_query($connect, $query);
      if (mysqli_num_rows ($result) > 0)
      {
        while($row = mysqli_fetch_array ($result))
        {
          ?>
          <div class="col-md-4">
            <form action="cart.php?action=add&id = <?php echo $row["id"]; ?> "method="post">
              <div style="border:1px solid #333; background-color:pink;">
                <img src="<?php echo $row["image"];  ?>" class="img-responsive"> <br>
                <h4 class="text-info"> <?php echo $row["name"]; ?> </h4>
                <h4 class="text-danger"> $ <?php echo $row["price"]; ?> </h4>

                <input type="text" name="quantity" class="form-control" value="1">
              </div>
            </form>
          </div>
          <?php
        }
      }

       ?>
    </div>

  </body>
</html>
