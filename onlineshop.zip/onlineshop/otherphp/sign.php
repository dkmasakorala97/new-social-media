<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="css/sf.css" rel="stylesheet" type="text/css">

</head>
<center>
<body>

<div class="signin">

	<form>

		<h2 style="color: white"> LOG IN </h2>
		<input type="text" name="username" placeholder="username">
		<input type="password" name="pass" placeholder="password"><br>
		<a href="cong.html"><input type="button" value="log in"></a> <br><br>
		<div id="container">

		</div><br> <br> <br> <br>

		Don't have account? <a href="jsform.html"> &nbsp; Sign Up </a>

	</form>
</div>

</body>
</center>
</html>
